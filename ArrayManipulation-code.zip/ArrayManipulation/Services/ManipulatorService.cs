﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ArrayManipulation.Services
{
    public class ManipulatorService
    {
        //Method to reverse the array
        public int[] ReverseArray(string[] productIds)
        {
            int arrayLength = productIds.Length;
            int[] result = new int[arrayLength];
            int resultIndex = 0;
            for (int index = arrayLength - 1; index >= 0; index--)
            {
                result[resultIndex] = ConvertValueToNumber(productIds[index]);
                resultIndex++;
            }
            return result;
        }

        //Method to delete a part from an array
        public int[] DeleteArray(string position, string[] productIds)
        {
            int arrayLength = productIds.Length;
            var deletePosition = string.IsNullOrEmpty(position) ? 0 : ConvertValueToNumber(position);
            int resultLength = (deletePosition < 1 || deletePosition > arrayLength) ? arrayLength : arrayLength - 1;
            int[] result = new int[resultLength];
            int resultIndex = 0;
            for (int index=0; index <= arrayLength - 1; index++)
            {
                if (index != deletePosition-1)
                {
                    result[resultIndex] = ConvertValueToNumber(productIds[index]);
                    resultIndex++;
                }
            }
            return result;
        }

        //Method to check if position or id is Number or not
        private int ConvertValueToNumber(string idValue)
        {
            int returnID;
            if (!int.TryParse(idValue, out returnID))
            {
                throw new Exception("position or productID is not Number");
            }
            return returnID;
        }
    }
}
