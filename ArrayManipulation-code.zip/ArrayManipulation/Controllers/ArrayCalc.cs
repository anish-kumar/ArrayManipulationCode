﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ArrayManipulation.Services;

namespace ArrayManipulation.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ArrayCalc : ControllerBase
    {
        ManipulatorService manipulator = new ManipulatorService();

        //api/arraycalc - Array Manipulation API Home Page
        [HttpGet]
        public ActionResult<string> Home()
        {
            return "Array Manipulation API Home Page";
        }

        //api/arraycalc/reverse - Pointing to this method to reverse the array in QueryString from Browser
        [HttpGet("reverse")]
        public ActionResult ArrayReverse([FromQuery]string[] productIds)
        {
            try
            {
                //calling ReverseArray method from Manipulator Service
                var result = manipulator.ReverseArray(productIds);
                return Ok(result);
            }
            catch (Exception e)
            {
                return BadRequest("Error while reversing array: " + e.Message);
            }            
        }

        //api/arraycalc/reverse - Pointing to this method to reverse the array in QueryString from Browser
        [HttpGet("deletepart")]
        public ActionResult ArrayDelete([FromQuery] string position, [FromQuery] string[] productIds)
        {
            try
            {
                //calling ReverseArray method from Manipulator Service
                var result = manipulator.DeleteArray(position, productIds);
                return Ok(result);
            }
            catch (Exception e)
            {
                return BadRequest("Error while deleting a number from array: " + e.Message);
            }
        }
    }
}
