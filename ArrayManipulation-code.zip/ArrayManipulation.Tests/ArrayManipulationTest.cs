using Microsoft.VisualStudio.TestTools.UnitTesting;
using ArrayManipulation;
using ArrayManipulation.Services;
using ArrayManipulation.Controllers;

namespace ArrayManipulation.Tests
{
    [TestClass]
    public class ArrayManipulationTest
    {
        ArrayCalc _controller;
        ManipulatorService _service;

        public ArrayManipulationTest()
        {
            _service = new ManipulatorService();
            _controller = new ArrayCalc();
        }

        [TestMethod]
        public void GetReverseOrder()
        {
            string[] array = { "1", "2", "3", "4", "5" };
            int[] expectedResult = { 5, 4, 3, 2, 1 };
            int[] result = _service.ReverseArray(array);

            //Assert.AreEqual(result, expectedResult);
            Assert.AreEqual(expectedResult.Length, result.Length);
            for (var i = 0; i < expectedResult.Length; i++)
            {
                Assert.AreEqual(expectedResult[i], result[i]);
            }
        }

        [TestMethod]
        public void GetDeleteArray()
        {
            var position = "3";
            string[] array = { "1", "2", "3", "4", "5" };
            int[] expectedResult = { 1, 2, 4, 5 };
            int[] result = _service.DeleteArray(position, array);

            //Assert.AreEqual(result, expectedResult);
            Assert.AreEqual(expectedResult.Length, result.Length);
            for (var i = 0; i < expectedResult.Length; i++)
            {
                Assert.AreEqual(expectedResult[i], result[i]);
            }
        }
    }
}
