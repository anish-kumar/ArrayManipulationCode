﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ArrayManipulation;
using ArrayManipulation.Services;

namespace ArrayManipulation.Tests.Services
{
    class ManipulatorServiceTest
    {
        [TestMethod]
        public void ReverseArray_ReturnsReversedArray()
        {
            string[] array = { "1", "2", "3", "4", "5" };
            int[] expectedResult = { 5, 4, 3, 2, 1 };

            var arrayManipulationService = new ManipulatorService();
            var result = arrayManipulationService.ReverseArray(array);

            Assert.AreEqual(expectedResult, result);
        }

        [TestMethod]
        public void DeleteArrayElement_ReturnsArrayWithElementRemoved()
        {
            var position = "3";
            string[] array = { "1", "2", "3", "4", "5" };
            int[] expectedResult = { 1, 2, 4, 5 };

            var arrayManipulationService = new ManipulatorService();
            var result = arrayManipulationService.DeleteArray(position,array);

            Assert.AreEqual(expectedResult, result);
        }
    }
}
